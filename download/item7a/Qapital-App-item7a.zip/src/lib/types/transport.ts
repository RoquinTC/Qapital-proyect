/**
 * Transport Domain — Canonical API Response Types
 *
 * Types for vehicles, fuel logs, and maintenance records.
 * Money fields are `number` (serialized from Prisma Decimal).
 * Distance/volume fields are `number` (stored as Float in Prisma).
 */

import type { SubAccount } from "./finance";

export interface Vehicle {
  id: string;
  name: string;
  type: string;
  brand?: string | null;
  model?: string | null;
  year?: number | null;
  color?: string | null;
  tankCapacity?: number | null;
  fuelType?: string | null;
  currentKm: number;
  icon?: string | null;
  fuelLogs?: FuelLog[];
  maintenanceRecords?: MaintenanceRecord[];
}

export interface FuelLog {
  id: string;
  vehicleId?: string;
  date: string;
  km: number;
  amount: number;
  pricePerGallon: number;
  gallons: number;
  isFullTank: boolean;
  notes?: string | null;
}

export interface MaintenanceRecord {
  id: string;
  vehicleId?: string;
  type: string;
  description: string;
  cost: number;
  km: number;
  date: string;
  nextDueKm?: number | null;
  nextDueDate?: string | null;
  reminderEnabled: boolean;
}

export interface FuelLevelData {
  fuelLevel: number;
  currentFuel: number;
  estimatedRange: number;
  avgKmPerGallon: number;
  lastFullTankDate: string | null;
  lastFullTankKm: number;
  totalConsumed: number;
  anomalyDetected: boolean;
  expectedConsumption: number;
  actualConsumption: number;
}

export interface FuelPriceData {
  fuelType: string;
  pricePerGallon: number;
  updatedAt: string;
}
