/**
 * Canonical Type Definitions — Central Re-Export
 *
 * Import from "@/lib/types" in component files:
 *
 *   import { Account, Transaction, Budget } from "@/lib/types";
 */

// ─── Finance ─────────────────────────────────────────────────────────────────
export type {
  AccountReference,
  SubAccountReference,
  SharedAccountUser,
  SubAccount,
  Account,
  Transaction,
  Budget,
  Installment,
  AbonoDetail,
  Abono,
  Debt,
  RecurringPayment,
  PayrollGroup,
  SavingsContribution,
  SavingsGoalAccount,
  SavingsGoal,
  CDTGoal,
  CDTAccount,
  CDTData,
  YieldItem,
  MonthlyData,
  MonthlySummaryResponse,
} from "./finance";

// ─── Transport ───────────────────────────────────────────────────────────────
export type {
  Vehicle,
  FuelLog,
  MaintenanceRecord,
  FuelLevelData,
  FuelPriceData,
} from "./transport";

// ─── Common ──────────────────────────────────────────────────────────────────
export type {
  CategoryData,
  CategoriesByType,
  UserSettings,
} from "./common";

// ─── Sync ────────────────────────────────────────────────────────────────────
export type {
  SyncStatus,
  SyncMeta,
  SyncOperation,
  SyncQueueItem,
  MutationOperation,
  MutationQueueEntry,
} from "./sync";
