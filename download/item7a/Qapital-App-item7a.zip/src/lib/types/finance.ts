/**
 * Finance Domain — Canonical API Response Types
 *
 * These types represent the shape of data returned by the finance API
 * endpoints AFTER serialization (Prisma Decimal → number, Date → ISO string).
 *
 * Components should import from here instead of declaring inline interfaces.
 * Optional fields marked with `?` may not be present in every API response
 * (e.g., nested relations are only included when explicitly requested).
 */

// ─── Shared Nested Shapes ────────────────────────────────────────────────────

/** Lightweight account reference embedded in transactions & recurring payments */
export interface AccountReference {
  id: string;
  name: string;
  type?: string;
  color: string;
  balance?: number;
}

/** Lightweight sub-account reference embedded in transactions */
export interface SubAccountReference {
  id: string;
  name: string;
  color?: string;
}

/** User within a shared account */
export interface SharedAccountUser {
  id: string;
  user: { name: string; email: string };
}

// ─── SubAccount ──────────────────────────────────────────────────────────────

export interface SubAccount {
  id: string;
  name: string;
  type: string;
  balance: number;
  isHighYield: boolean;
  yieldPercentage?: number | null;
  color?: string | null;
  icon?: string | null;
  excludeFromAvailable?: boolean;
  order: number;
}

// ─── Account ─────────────────────────────────────────────────────────────────

export interface Account {
  id: string;
  name: string;
  type: string;
  color: string;
  icon?: string | null;
  balance: number;
  isHighYield: boolean;
  yieldPercentage?: number | null;
  isShared: boolean;
  excludeFromAvailable?: boolean;
  order?: number;
  bank?: string;
  subAccounts: SubAccount[];
  sharedUsers?: SharedAccountUser[];
  transactions?: Transaction[];
  createdAt?: string;
  updatedAt?: string;
}

// ─── Transaction ─────────────────────────────────────────────────────────────

export interface Transaction {
  id: string;
  type: string;
  amount: number;
  description: string;
  category?: string | null;
  subCategory?: string | null;
  date: string;
  accountId?: string | null;
  subAccountId?: string | null;
  notes?: string | null;
  sourceModule?: string | null;
  sourceId?: string | null;
  isRecurring?: boolean;
  excludeFromBudget?: boolean;
  account?: AccountReference | null;
  subAccount?: SubAccountReference | null;
  transferToAccount?: AccountReference | null;
  isTransferCounterpart?: boolean;
  transferFromAccount?: AccountReference | null;
}

// ─── Budget ──────────────────────────────────────────────────────────────────

export interface Budget {
  id: string;
  type: string;
  category: string;
  subCategory?: string | null;
  amount: number;
  spent: number;
  period: string;
  icon?: string | null;
  color?: string | null;
}

// ─── Installment ─────────────────────────────────────────────────────────────

export interface Installment {
  id: string;
  description: string;
  totalAmount: number;
  totalInstallments: number;
  currentInstallment: number;
  installmentAmount: number;
  paidAmount: number;
  interestRate?: number | null;
  interestAmount?: number | null;
  otherChargesAmount?: number | null;
  remainingBalance?: number | null;
  purchaseDate: string;
  nextPaymentDate: string;
  isPaid: boolean;
  accountId?: string | null;
  subAccountId?: string | null;
  category?: string | null;
  subCategory?: string | null;
}

// ─── Abono ───────────────────────────────────────────────────────────────────

export interface AbonoDetail {
  id: string;
  installmentId: string;
  amount: number;
  previousBalance: number;
  newBalance: number;
}

export interface Abono {
  id: string;
  debtId: string;
  transactionId?: string | null;
  totalAmount: number;
  accountId: string;
  subAccountId?: string | null;
  date: string;
  isReversed: boolean;
  createdAt?: string;
  details: AbonoDetail[];
}

// ─── Debt ────────────────────────────────────────────────────────────────────

export interface Debt {
  id: string;
  type: string;
  name: string;
  color: string;
  icon?: string | null;
  bank?: string | null;
  totalAmount: number;
  currentBalance: number;
  interestRate?: number | null;
  cutoffDate?: number | null;
  paymentDate?: number | null;
  monthlyPayment?: number | null;
  remainingPayments?: number | null;
  paymentType?: string | null;
  otherCharges?: number | null;
  category?: string | null;
  subCategory?: string | null;
  accountId?: string | null;
  subAccountId?: string | null;
  startDate?: string | null;
  endDate?: string | null;
  installments?: Installment[];
  abonos?: Abono[];
}

// ─── Recurring Payment ───────────────────────────────────────────────────────

export interface RecurringPayment {
  id: string;
  description: string;
  amount: number;
  actualAmount: number | null;
  type: string;
  accountId: string | null;
  subAccountId: string | null;
  debtId: string | null;
  destinationAccountId: string | null;
  destinationSubAccountId: string | null;
  category: string | null;
  subCategory: string | null;
  scheduledDate: string;
  confirmedDate: string | null;
  status: string;
  frequency: string;
  notes: string | null;
  isRecurring: boolean;
  payrollGroupId: string | null;
  createdAt?: string;
  updatedAt?: string;
  account?: AccountReference | null;
  debt?: { id: string; name: string; type: string; color: string; currentBalance: number } | null;
  destinationAccount?: AccountReference | null;
}

// ─── Payroll Group ───────────────────────────────────────────────────────────

export interface PayrollGroup {
  id: string;
  description: string;
  frequency: string;
  totalAmount: number;
  accountId: string;
  subAccountId: string | null;
  category: string;
  subCategory: string | null;
  adjustToBusinessDay: boolean;
  businessDayDirection: string;
  schedules: string;
  isActive: boolean;
  account?: AccountReference | null;
  subAccount?: SubAccountReference | null;
  recurringPayments?: Array<{ id: string; scheduledDate: string; status: string }>;
}

// ─── Savings Goal ────────────────────────────────────────────────────────────

export interface SavingsContribution {
  id: string;
  amount: number;
  date: string;
  description?: string | null;
  accountId?: string | null;
}

export interface SavingsGoalAccount {
  id: string;
  goalId: string;
  accountId: string;
  subAccountId?: string | null;
  account: {
    id: string;
    name: string;
    type: string;
    color: string;
    balance: number;
    subAccounts?: SubAccount[];
  };
  subAccount?: {
    id: string;
    name: string;
    balance: number;
    color?: string;
  } | null;
}

export interface SavingsGoal {
  id: string;
  name: string;
  description?: string | null;
  targetAmount: number;
  currentAmount: number;
  deadline?: string | null;
  type: string;
  color: string;
  icon?: string | null;
  aiSuggestion?: string | null;
  isActive: boolean;
  frequency?: string;
  monthlyDay?: number | null;
  biweeklyDays?: string | null;
  weeklyDay?: number | null;
  periodAmounts?: string | null;
  sourceAccountId?: string | null;
  destinationAccountId?: string | null;
  sourceAccount?: { id: string; name: string; type: string } | null;
  destinationAccount?: { id: string; name: string; type: string } | null;
  contributions: SavingsContribution[];
  linkedAccounts: SavingsGoalAccount[];
  cdts: CDTData[];
}

// ─── CDT (Certificado de Deposito a Termino) ────────────────────────────────

export interface CDTGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
}

export interface CDTAccount {
  id: string;
  name: string;
  type: string;
  color: string;
  balance?: number;
  subAccounts?: SubAccount[];
}

export interface CDTData {
  id: string;
  bank: string;
  amount: number;
  effectiveRate: number;
  startDate: string;
  endDate: string;
  termDays: number;
  interestEarned: number;
  status: string;
  goalId: string | null;
  accountId: string | null;
  withdrawnAmount: number | null;
  withdrawnDate: string | null;
  notes: string | null;
  color: string;
  createdAt?: string;
  updatedAt?: string;
  goal?: CDTGoal | null;
  account?: CDTAccount | null;
}

// ─── Yield ───────────────────────────────────────────────────────────────────

export interface YieldItem {
  id: string | null;
  accountId: string | null;
  subAccountId: string | null;
  parentAccountId: string | null;
  accountName: string;
  balance: number;
  yieldPercentage: number;
  projectedYield: number;
  actualYield: number | null;
  isConfirmed: boolean;
  transactionId: string | null;
  isPreviousMonth?: boolean;
  previousMonth?: string;
}

// ─── Monthly Summary ─────────────────────────────────────────────────────────

export interface MonthlyData {
  month: string;
  income: number;
  expenses: number;
  balance: number;
}

export interface MonthlySummaryResponse {
  historical: MonthlyData[];
  projection: MonthlyData[];
  averages: {
    monthlyIncome: number;
    monthlyExpenses: number;
    monthlySavings: number;
  };
}
