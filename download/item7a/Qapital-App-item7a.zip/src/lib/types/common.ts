/**
 * Common / Shared Types
 *
 * Types used across multiple domain modules.
 */

/** Category structure returned by /api/categories */
export interface CategoryData {
  name: string;
  subcategories: string[];
}

/** Categories grouped by type (income / expense) */
export interface CategoriesByType {
  income: CategoryData[];
  expense: CategoryData[];
}

/** User settings shape */
export interface UserSettings {
  budgetCutoffDay: number;
  respectHolidays: boolean;
}
