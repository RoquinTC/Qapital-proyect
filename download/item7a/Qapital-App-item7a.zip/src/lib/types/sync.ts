/**
 * Sync & Offline Infrastructure Types
 *
 * Shared between the two Dexie database layers (index.ts and db.ts).
 * These types define the sync metadata that local records carry,
 * the sync queue structure, and the mutation queue entries.
 */

// ─── Sync Metadata (db.ts style — prefixed with underscore) ──────────────────

export type SyncStatus = "synced" | "pending_create" | "pending_update" | "pending_delete" | "conflict";

export interface SyncMeta {
  _syncStatus: SyncStatus;
  _version: number;
  _lastModified: number;
}

// ─── Sync Queue (index.ts style) ────────────────────────────────────────────

export type SyncOperation = "create" | "update" | "delete";

export interface SyncQueueItem {
  id?: number;
  table: string;
  operation: SyncOperation;
  serverUrl: string;
  method: string;
  body?: string;
  tempId?: string;
  createdAt: number;
  retryCount: number;
  lastError?: string;
}

// ─── Mutation Queue (db.ts style) ───────────────────────────────────────────

export type MutationOperation = "create" | "update" | "delete" | "complex";

export interface MutationQueueEntry {
  id: string;
  operation: MutationOperation;
  tableName: string;
  recordId: string;
  payload: string;
  apiRoute?: string;
  apiMethod?: string;
  snapshot?: string;
  sequence: number;
  status: "pending" | "in_progress" | "completed" | "failed";
  retryCount: number;
  error?: string;
  createdAt: number;
  updatedAt: number;
  groupId?: string;
}
